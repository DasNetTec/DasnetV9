package com.example.dasnet;

public class Config {
    // IP config for the complete project
    public static final String BASE_IP = "192.168.115.51";  // Global IP
}