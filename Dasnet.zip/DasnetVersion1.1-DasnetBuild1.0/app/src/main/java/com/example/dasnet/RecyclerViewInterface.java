package com.example.dasnet;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
