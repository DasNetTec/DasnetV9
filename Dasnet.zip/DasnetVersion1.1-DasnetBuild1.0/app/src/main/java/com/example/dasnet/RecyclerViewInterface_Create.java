package com.example.dasnet;

public interface RecyclerViewInterface_Create {
    void onItemClick(int position);
}